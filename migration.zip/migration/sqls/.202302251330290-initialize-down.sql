/*Replace with your SQL command*/
ALTER TABLE movie
ADD COLUMN rating
