/*Replace with your SQL command*/
ALTER TABLE movie
DROP COLUMN rating
